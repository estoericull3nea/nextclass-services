<?php
/** Google Calendar settings and OAuth handlers. @package NextClassServices */
namespace NextClassServices\Admin;

use NextClassServices\Booking\Google_Calendar;
use NextClassServices\Booking\Appointment;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Google_Calendar_Settings {
	public static function init() {
		foreach ( array( 'save', 'connect', 'callback', 'disconnect', 'test', 'retry' ) as $action ) {
			add_action( 'admin_post_ncs_google_' . $action, array( __CLASS__, 'handle_' . $action ) );
		}
	}

	private static function authorize( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Only administrators can manage Google Calendar credentials.', 'next-class-services' ), '', array( 'response' => 403 ) );
		}
		Admin::authorize( Settings::CAP, 'ncs_google_' . $action, '_ncs_nonce' );
	}

	private static function input( $key, $source ) {
		return isset( $source[ $key ] ) && is_string( $source[ $key ] ) ? trim( wp_unslash( $source[ $key ] ) ) : '';
	}

	private static function finish( $message, $type = 'success' ) {
		Admin::flash( $type, $message );
		Admin::redirect( Admin::url( 'ncs-settings' ) . '#ncs-google-calendar' );
	}

	private static function form_start( $action ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="ncs-form"><input type="hidden" name="action" value="ncs_google_' . esc_attr( $action ) . '">';
		wp_nonce_field( 'ncs_google_' . $action, '_ncs_nonce' );
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$c = Google_Calendar::config();
		echo '<div class="ncs-card" id="ncs-google-calendar"><h2 class="ncs-card-title">' . esc_html__( 'Google Calendar and Google Meet', 'next-class-services' ) . '</h2>';
		echo '<p>' . esc_html( Google_Calendar::connected() ? __( 'Account connected. Use the test below to verify calendar access and Meet creation.', 'next-class-services' ) : __( 'Account not connected.', 'next-class-services' ) ) . '</p>';
		echo '<p class="ncs-help">' . esc_html__( 'Enable the Google Calendar API in Google Cloud, configure the OAuth consent screen, and create a Web application OAuth client. An API key alone cannot create calendar events. Add this exact authorized redirect URI:', 'next-class-services' ) . '</p><p><code>' . esc_html( Google_Calendar::redirect_uri() ) . '</code></p>';
		echo '<p class="ncs-help">' . esc_html__( 'For an External app in Testing, add your Google account as a test user. Google may expire testing refresh tokens after seven days. Use a production OAuth app for ongoing bookings. The connected calendar must support Google Meet.', 'next-class-services' ) . '</p>';
		self::form_start( 'save' );
		Form::text( 'client_id', __( 'Google OAuth client ID', 'next-class-services' ), $c['client_id'] );
		Form::text( 'client_secret', __( 'Google OAuth client secret', 'next-class-services' ), '', array( 'type' => 'password', 'attrs' => array( 'autocomplete' => 'new-password' ), 'help' => $c['secret'] ? __( 'A secret is saved. Leave blank to keep it. Secrets are encrypted and never displayed.', 'next-class-services' ) : __( 'Enter the client secret from Google Cloud.', 'next-class-services' ) ) );
		Form::text( 'calendar_id', __( 'Google calendar ID', 'next-class-services' ), $c['calendar_id'], array( 'help' => __( 'Use primary for the connected account, or copy a calendar ID from Google Calendar settings. Changes apply to new bookings; existing events keep their calendar.', 'next-class-services' ) ) );
		echo '<button type="submit" class="ncs-btn ncs-btn-primary">' . esc_html__( 'Save Google configuration', 'next-class-services' ) . '</button></form>';
		echo '<p class="ncs-help">' . esc_html__( 'Save configuration before connecting or testing. Enable sync per service in Booking, General. Sync sends generic event titles and booking times to Google; customer names, email addresses and notes are not sent. Meet links appear in appointment details, customer booking management and plugin emails. Google attendee invitations are not sent. Google Calendar busy times are not imported.', 'next-class-services' ) . '</p>';
		echo '<div class="ncs-item-actions">';
		foreach ( array( 'connect' => __( 'Connect / reconnect Google', 'next-class-services' ), 'test' => __( 'Test Calendar and Meet API', 'next-class-services' ), 'disconnect' => __( 'Disconnect Google', 'next-class-services' ) ) as $action => $label ) {
			self::form_start( $action );
			echo '<button type="submit" class="ncs-btn">' . esc_html( $label ) . '</button></form>';
		}
		echo '</div><p class="ncs-help">' . esc_html__( 'The test creates a temporary event with Meet, updates its time, and deletes it. If Meet generation is still pending, the result says so. Failed booking syncs retry automatically through WordPress scheduled tasks; a working WP-Cron is required.', 'next-class-services' ) . '</p>';
		$test = get_option( 'ncs_google_test_result', array() );
		if ( ! empty( $test['message'] ) ) {
			echo '<p role="status">' . esc_html( $test['date'] . ': ' . $test['message'] ) . '</p>';
		}
		echo '</div>';
	}

	public static function handle_save() {
		self::authorize( 'save' );
		$c = Google_Calendar::config();
		$id = sanitize_text_field( self::input( 'client_id', $_POST ) );
		$secret = self::input( 'client_secret', $_POST );
		$changed = $id !== $c['client_id'] || ( '' !== $secret && $secret !== Google_Calendar::decrypt( $c['secret'] ) );
		if ( '' !== $secret ) {
			$encrypted = Google_Calendar::encrypt( $secret );
			if ( is_wp_error( $encrypted ) ) {
				self::finish( $encrypted->get_error_message(), 'error' );
			}
			$c['secret'] = $encrypted;
		}
		$c['client_id'] = $id;
		$c['calendar_id'] = sanitize_text_field( self::input( 'calendar_id', $_POST ) );
		if ( '' === $c['calendar_id'] ) {
			$c['calendar_id'] = 'primary';
		}
		if ( $changed ) {
			$c['tokens'] = '';
		}
		Google_Calendar::save_config( $c );
		self::finish( __( 'Google configuration saved. Connect or reconnect if credentials changed, then run the API test.', 'next-class-services' ) );
	}

	public static function handle_connect() {
		self::authorize( 'connect' );
		$c = Google_Calendar::config();
		if ( ! $c['client_id'] || ! Google_Calendar::decrypt( $c['secret'] ) ) {
			self::finish( __( 'Save an OAuth client ID and secret first.', 'next-class-services' ), 'error' );
		}
		$state = bin2hex( random_bytes( 32 ) );
		set_transient( 'ncs_google_state_' . hash( 'sha256', $state ), array( 'user' => get_current_user_id(), 'session' => hash( 'sha256', wp_get_session_token() ), 'client' => hash( 'sha256', $c['client_id'] . $c['secret'] ) ), 10 * MINUTE_IN_SECONDS );
		$url = add_query_arg( array(
			'client_id' => $c['client_id'], 'redirect_uri' => Google_Calendar::redirect_uri(), 'response_type' => 'code',
			'scope' => 'https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.calendars.readonly',
			'access_type' => 'offline', 'prompt' => 'consent', 'state' => $state,
		), 'https://accounts.google.com/o/oauth2/v2/auth' );
		wp_redirect( $url ); // Fixed Google authorization host, not user-provided.
		exit;
	}

	public static function handle_callback() {
		if ( ! current_user_can( 'manage_options' ) || ! current_user_can( Settings::CAP ) ) {
			wp_die( esc_html__( 'You cannot connect Google Calendar.', 'next-class-services' ), '', array( 'response' => 403 ) );
		}
		$state = self::input( 'state', $_GET );
		if ( ! preg_match( '/^[a-f0-9]{64}$/', $state ) ) {
			self::finish( __( 'Invalid Google authorization state. Start the connection again.', 'next-class-services' ), 'error' );
		}
		$key = 'ncs_google_state_' . hash( 'sha256', $state );
		$saved = get_transient( $key );
		$c = Google_Calendar::config();
		if ( ! is_array( $saved ) || (int) $saved['user'] !== get_current_user_id() || ! hash_equals( $saved['session'], hash( 'sha256', wp_get_session_token() ) ) || ! hash_equals( $saved['client'], hash( 'sha256', $c['client_id'] . $c['secret'] ) ) ) {
			self::finish( __( 'Google authorization expired or belongs to another session. Connect again.', 'next-class-services' ), 'error' );
		}
		delete_transient( $key );
		$code = self::input( 'code', $_GET );
		if ( '' === $code || '' !== self::input( 'error', $_GET ) ) {
			self::finish( __( 'Google authorization was declined or incomplete.', 'next-class-services' ), 'error' );
		}
		$result = Google_Calendar::token_request( array( 'grant_type' => 'authorization_code', 'code' => $code, 'redirect_uri' => Google_Calendar::redirect_uri() ) );
		self::finish( is_wp_error( $result ) ? $result->get_error_message() : __( 'Google account connected. Run the Calendar and Meet API test.', 'next-class-services' ), is_wp_error( $result ) ? 'error' : 'success' );
	}

	public static function handle_disconnect() {
		self::authorize( 'disconnect' );
		$c = Google_Calendar::config();
		$c['tokens'] = '';
		Google_Calendar::save_config( $c );
		self::finish( __( 'Google disconnected locally. Existing events remain in Google Calendar. Reconnect to resume pending changes. You can revoke app access in your Google account.', 'next-class-services' ) );
	}

	public static function handle_test() {
		self::authorize( 'test' );
		$result = self::test_connection();
		$message = is_wp_error( $result ) ? $result->get_error_message() : $result;
		update_option( 'ncs_google_test_result', array( 'date' => current_time( 'mysql' ), 'message' => $message ), false );
		self::finish( $message, is_wp_error( $result ) ? 'error' : 'success' );
	}

	/** Persist a test event's ID before POST so cleanup also works after a timeout. */
	public static function test_connection() {
		global $wpdb;
		$lock = 'ncs_google_test_' . md5( $wpdb->prefix );
		if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) ) ) {
			return new \WP_Error( 'busy', __( 'A Google API test is already running. Wait for it to finish.', 'next-class-services' ) );
		}
		try {
			return self::run_test();
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	private static function run_test() {
		$pending = get_option( 'ncs_google_test_event', array() );
		if ( $pending ) {
			$cleanup = Google_Calendar::request( 'DELETE', Google_Calendar::events_path( $pending['calendar'], $pending['id'] ) . '?sendUpdates=none' );
			if ( is_wp_error( $cleanup ) && ! Google_Calendar::missing( $cleanup ) ) {
				return new \WP_Error( 'cleanup', __( 'The previous test event could not be deleted. Reconnect the original account and run the test again.', 'next-class-services' ) );
			}
			delete_option( 'ncs_google_test_event' );
		}
		$c = Google_Calendar::config();
		$cal = Google_Calendar::request( 'GET', 'calendars/' . rawurlencode( $c['calendar_id'] ) );
		if ( is_wp_error( $cal ) ) {
			return $cal;
		}
		if ( ! in_array( 'hangoutsMeet', isset( $cal['conferenceProperties']['allowedConferenceSolutionTypes'] ) ? $cal['conferenceProperties']['allowedConferenceSolutionTypes'] : array(), true ) ) {
			return new \WP_Error( 'meet', __( 'Calendar access works, but this calendar does not support Google Meet.', 'next-class-services' ) );
		}
		$id = bin2hex( random_bytes( 16 ) );
		$path = Google_Calendar::events_path( $cal['id'], $id );
		$start = time() + DAY_IN_SECONDS;
		$body = array( 'id' => $id, 'summary' => 'Next Class API connection test', 'start' => array( 'dateTime' => gmdate( 'Y-m-d\TH:i:s\Z', $start ) ), 'end' => array( 'dateTime' => gmdate( 'Y-m-d\TH:i:s\Z', $start + 900 ) ), 'conferenceData' => Google_Calendar::conference() );
		update_option( 'ncs_google_test_event', array( 'calendar' => $cal['id'], 'id' => $id ), false );
		$result = Google_Calendar::request( 'POST', Google_Calendar::events_path( $cal['id'] ) . '?conferenceDataVersion=1&sendUpdates=none', $body );
		if ( ! is_wp_error( $result ) ) {
			$result = Google_Calendar::request( 'PATCH', $path . '?conferenceDataVersion=1&sendUpdates=none', array( 'start' => array( 'dateTime' => gmdate( 'Y-m-d\TH:i:s\Z', $start + 3600 ) ), 'end' => array( 'dateTime' => gmdate( 'Y-m-d\TH:i:s\Z', $start + 4500 ) ) ) );
		}
		$cleanup = Google_Calendar::request( 'DELETE', $path . '?sendUpdates=none' );
		if ( is_wp_error( $cleanup ) && ! Google_Calendar::missing( $cleanup ) ) {
			/* translators: %s: Google event ID */
			return new \WP_Error( 'cleanup', sprintf( __( 'Test cleanup failed. A temporary event may remain (ID: %s). Run the test again to retry cleanup.', 'next-class-services' ), $id ) );
		}
		delete_option( 'ncs_google_test_event' );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$status = isset( $result['conferenceData']['createRequest']['status']['statusCode'] ) ? $result['conferenceData']['createRequest']['status']['statusCode'] : '';
		if ( 'failure' === $status ) {
			return new \WP_Error( 'meet', __( 'Event creation, update and deletion passed, but Google Meet generation failed.', 'next-class-services' ) );
		}
		return Google_Calendar::meet_url( $result ) ? __( 'Passed: event created, Google Meet link generated, event rescheduled and test event deleted.', 'next-class-services' ) : __( 'Event creation, rescheduling and deletion passed. Meet creation was requested but was still pending; Meet generation is not yet verified.', 'next-class-services' );
	}

	public static function handle_retry() {
		Admin::authorize( Appointments::CAP, 'ncs_google_retry', '_ncs_nonce' );
		$id = absint( self::input( 'id', $_POST ) );
		Google_Calendar::sync_now( $id );
		$a = Appointment::get( $id );
		Admin::flash( $a && empty( $a['google_sync_error'] ) ? 'success' : 'error', $a && ! empty( $a['google_sync_error'] ) ? $a['google_sync_error'] : __( 'Calendar sync processed.', 'next-class-services' ) );
		Admin::redirect( Admin::url( 'ncs-appointments', array( 'action' => 'view', 'id' => $id ) ) );
	}
}
